DROP TABLE container_base_value;
DROP TABLE container;
DROP TABLE device_base_value;
DROP TABLE device;
DROP TABLE base_value_manifest;
DROP TABLE base_value_pcr_info;
DROP TABLE client_info;
DROP TABLE trust_report_manifest;
DROP TABLE trust_report_pcr_info;
DROP TABLE trust_report;
DROP TABLE register_client;

