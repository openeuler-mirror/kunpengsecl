TRUNCATE TABLE container_base_value CASCADE;
TRUNCATE TABLE container CASCADE;
TRUNCATE TABLE device_base_value CASCADE;
TRUNCATE TABLE device CASCADE;
TRUNCATE TABLE base_value_manifest CASCADE;
TRUNCATE TABLE base_value_pcr_info CASCADE;
TRUNCATE TABLE client_info CASCADE;
TRUNCATE TABLE trust_report_manifest  CASCADE;
TRUNCATE TABLE trust_report_pcr_info CASCADE;
TRUNCATE TABLE trust_report CASCADE;
TRUNCATE TABLE register_client CASCADE;

