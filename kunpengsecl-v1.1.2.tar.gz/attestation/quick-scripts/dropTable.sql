DROP TABLE client;
DROP TABLE report;
DROP TABLE base;
